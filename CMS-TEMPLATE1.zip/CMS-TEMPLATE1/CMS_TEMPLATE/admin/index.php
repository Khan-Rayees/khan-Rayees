<?php include "includes/admin_header.php" ?>


    <div id="wrapper">


        <!-- Navigation -->

<?php include "includes/admin_navigation.php" ?>


        <div id="page-wrapper">



            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">


                        <h1 class="page-header">
                            Welcome to Admin
                            <small><?php echo $_SESSION['username'] ?></small>
                        </h1>


                    </div>
                </div>
                <!-- /.row -->


                <!-- /.row -->

<div class="row">
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-file-text fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">



   <div class='huge'><?php echo $posts_count = recordCount('posts'); ?></div>


            <div>Posts</div>
                    </div>
                </div>
            </div>
            <a href="posts.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-green">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-comments fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">

                    <!----function Calling users -->

                    <div class='huge'><?php echo $comment_count = recordCount('comments'); ?></div>


                      <div>Comments</div>
                    </div>
                </div>
            </div>
            <a href="comments.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-yellow">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-user fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">


                    <!----function Calling users -->

                   <div class='huge'><?php echo $user_count = recordCount('users'); ?></div>

                        <div> Users</div>
                    </div>
                </div>
            </div>
            <a href="users.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-red">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-list fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">

 <!----function Calling  -->
                       <div class='huge'><?php echo $category_count = recordCount('categories'); ?></div>

                         <div>Categories</div>
                    </div>
                </div>
            </div>
            <a href="categories.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
</div>
</div>
                <!-- /.row  Add Google ColumnChart -->


                <?php

                   $post_published_counts =  checkStatus('posts','post_status','published');
                   $post_draft_counts =  checkStatus('posts','post_status','draft');

                    $UnApproved_comment_counts = checkStatus('comments','comment_status','unapproved');
                    $subscriber_count = checkUserRole('users','user_role','subscriber');


                ?>




<div class="row">

   <script type="text/javascript">
            google.charts.load('current', {'packages':['corechart', 'bar']});
            google.charts.setOnLoadCallback(drawStuff);

            function drawStuff() {

              var button = document.getElementById('change-chart');
              var chartDiv = document.getElementById('chart_div');

              var data = google.visualization.arrayToDataTable([
                ['Data','Count'],



   <?php
       $elements_text = ['Active Posts','Draft Posts','Comments','Pending Comments','Users','Subscribers','categories'];
       $elements_count = [$post_count,$post_draft_counts ,$comment_count,$UnApproved_comment_counts,$users_count,$subscriber_count,$categories_count];
                 for($i =0;$i < 7; $i++){

                    echo "['{$elements_text[$i]}'"."," . "{$elements_count[$i]}],";

                 }

    ?>


              ]);

              var materialOptions = {
                width: 900,
                chart: {
                  title: '',
                  subtitle: ''
                },
                series: {
                  0: { axis: 'distance' }, // Bind series 0 to an axis named 'distance'.
                  1: { axis: 'brightness' } // Bind series 1 to an axis named 'brightness'.
                },
                axes: {
                  y: {
                    distance: {label: 'parsecs'}, // Left y-axis.
                    brightness: {side: 'right', label: 'apparent magnitude'} // Right y-axis.
                  }
                }
              };

              var classicOptions = {
                width: 900,
                series: {
                  0: {targetAxisIndex: 0},
                  1: {targetAxisIndex: 1}
                },
                title: 'Developed and Maintain By Khan Rayees',
                vAxes: {
                  // Adds titles to each axis.
                  0: {title: 'parsecs'},
                  1: {title: 'apparent magnitude'}
                }
              };

              function drawMaterialChart() {
                var materialChart = new google.charts.Bar(chartDiv);
                materialChart.draw(data, google.charts.Bar.convertOptions(materialOptions));
                button.innerText = 'Change to Classic';
                button.onclick = drawClassicChart;
              }

              function drawClassicChart() {
                var classicChart = new google.visualization.ColumnChart(chartDiv);
                classicChart.draw(data, classicOptions);
                button.innerText = 'Content';
                button.onclick = drawMaterialChart;
              }

              drawMaterialChart();
          };
          </script>



  <button id="change-chart">Change to Classic</button>
      <br><br>
      <div id="chart_div" style="width: auto; height: 500px;"></div>





                  </div>





            </div>
            <!-- /.container-fluid -->

        </div>


        <!-- /#page-wrapper -->
<?php include "includes/admin_footer.php" ?>