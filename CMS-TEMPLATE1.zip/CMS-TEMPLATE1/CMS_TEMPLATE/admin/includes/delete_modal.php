
  <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Modal Delete Box</h4>
          <button type="button" class="close" data-dismiss="modal">×</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <h3>Are You Sure You Want to Delete this Post?</h3>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
        <a href="" class="btn btn-danger modal_delete_link">Delete</a>
          <button type="button" class="btn btn-info" data-dismiss="modal">Cancel</button>
        </div>

      </div>
    </div>
  </div>

</div>
