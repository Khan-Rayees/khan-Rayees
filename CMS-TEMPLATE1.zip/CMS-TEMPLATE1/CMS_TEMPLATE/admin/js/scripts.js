$(document).ready(function(){
    //CKEDITOR
    ClassicEditor
        .create( document.querySelector( '#body'))
        .catch( error => {
            console.error(error);
        });
    //REST OF THE CODE


});





$(document).ready(function () {
    $('#selectAllBoxes').click(function (event) {
        if (this.checked){
            $('.checkBoxes').each(function () {
                this.checked = true;
            });

        }
        else {
            $('.checkBoxes').each(function () {
                this.checked = false;
            });

        }
        }


    let div_box = "<div id='load-screen'><div id='loading'></div></div>";
    $("body").prepend(div_box);
    $('#load-screen').delay(700).fadeOut(600, function () {
        $(this).remove();
    });




    google.charts.load('current', {'packages':['corechart', 'bar']});
    google.charts.setOnLoadCallback(drawStuff);

    function drawStuff() {

        var button = document.getElementById('change-chart');
        var chartDiv = document.getElementById('chart_div');

        var data = google.visualization.arrayToDataTable([
            ['Data','Count'],




    });







