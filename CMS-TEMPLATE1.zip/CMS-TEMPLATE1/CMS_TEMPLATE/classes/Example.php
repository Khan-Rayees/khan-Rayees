<?php

 Class Example{
    public function display(){
        echo "method from class";

    }

 }

 ?>