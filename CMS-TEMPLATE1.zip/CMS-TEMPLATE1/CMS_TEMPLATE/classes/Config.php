<?php
Class Config{
    const SMTP_HOST = 'smtp.mailtrap.io';

    const SMTP_PORT = 2525;

    const SMTP_USER = '2ddc401b6dd6c0';

    const SMTP_PASSWORD = 'b98dacf0496cf6';





}



?>