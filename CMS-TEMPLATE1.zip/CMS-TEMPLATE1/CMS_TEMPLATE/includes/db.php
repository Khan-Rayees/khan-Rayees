<?php
$db['db_host'] = "localhost";
$db['db_user'] = "id11936431_rayees";
$db['db_pass'] = "root123";
$db['db_name'] = "id11936431_cms";

foreach($db as $key => $value){
    define(strtoupper($key),$value);
}

$connection = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);
//if($connection){
  //  echo "you are connected";
//}


?>