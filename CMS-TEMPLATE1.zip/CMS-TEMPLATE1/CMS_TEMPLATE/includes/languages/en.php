<?php

const _REGISTER =  "Register";
const _USERNAME =  "Enter Your Username";
const _EMAIL =  "Enter Your Email";
const _PASSWORD =  "Enter Your Password";
