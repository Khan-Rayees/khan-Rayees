<?php

const _REGISTER =  "Registrate";
const _USERNAME =  "Nombre de Usuario";
const _EMAIL =  "Tu Correo";
const _PASSWORD =  "Tu Clave";
