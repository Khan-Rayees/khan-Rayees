    <!-- Footer -->
        <footer class="bg-dark">

            <div class="row">
                <div class="col-lg-12 ">
                    <h3>Copyright &copy; 2019 </h3>
                    <h6>All Rights Reserved</h6>
                    <h6>Developed & Maintained by Khan Rayees
                        <a class="text-dark" href="https://khanrayees.000webhostapp.com" target="_blank">
                            <i class="fa fa-users"> https://khanrayees.000webhostapp.com </i></a>
                    </h6>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
